import requests
import telebot
from telebot import types

TOKEN = "8598001945:AAEL8ZcUrCd3mqpaP7AHAj2tkD95HoYIfqc"
APP_ID = "9642d0ae"
APP_KEY = "5c99982088fc4a4b80ace77dbf4629c1"
url = "https://api.edamam.com/api/nutrition-data"
bot = telebot.TeleBot(TOKEN)
user_data = {} #eto slovar dlya hranenia ingredientov
user_settings ={} #a eto dlya hranenia nastroek usera
def calculator(weight, height, age, gender, activity, goal):
    if gender.lower() == "м":
        bmr = 10*weight + 6.25*height - 5*age +5
    else:
        bmr = 10*weight + 6.25*height - 5*age -161

    activity_factors ={
        "малоподвижнаый": 1.2,
        "легкая":1.375,
        "средняя":1.55,
        "высокая": 1.725,
        "интенсивная": 1.9
    }
    calories = bmr * activity_factors.get(activity, 1.2)
    if goal == "похудение":
        calories *= 0.8
    elif goal == "набор":
        calories *= 1.2
    return round(calories) #это поддержание веса
def start_menu(chat_id):
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("Ввести ингредиенты", callback_data="get_ingredients"),
        types.InlineKeyboardButton("Итоги дня", callback_data="result"),
        types.InlineKeyboardButton("Очистить", callback_data="clear"),
        types.InlineKeyboardButton("Помощь", callback_data="help"),
        types.InlineKeyboardButton("Мои настройки", callback_data="settings")
    )
    bot.send_message(chat_id,
                     "Привет! Добро пожаловать! Я ***NutriPal*** — твой помощник по подсчёту калорий и макроэлементов.\n"
                     "Выберите команду:\n",
                     reply_markup=markup
                     )
@bot.message_handler(commands=['start'])
def start(message):
    start_menu(message.chat.id)

@bot.callback_query_handler(func=lambda call: True)
def callback(call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id

    if call.data == "get_ingredients":
        bot.send_message(chat_id, "Введите ингредиенты через запятую и на английском языке.")
        bot.register_next_step_handler_by_chat_id(chat_id, get_ingredients)

    elif call.data == "result":
        show_result(chat_id)

    elif call.data == "clear":
        user_data[user_id] = []
        bot.send_message(chat_id, "Ура, ваш список очищён!")

    elif call.data == "help":
        bot.send_message(chat_id,
            "Введите ингредиенты в формате:\n"
            "1 cup rice,2 eggs,150 g apple\n"
            "В Настройках можно установить цель, норму или рассчитать её."
        )

    elif call.data == "settings":
        show_settings_menu(call.message)

    elif call.data == "goal":
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("Похудение", callback_data="goal_loss"),
            types.InlineKeyboardButton("Поддержание веса", callback_data="goal_maintain"),
            types.InlineKeyboardButton("Набор массы", callback_data="goal_gain"),
            types.InlineKeyboardButton("Назад", callback_data="back")
        )
        bot.send_message(chat_id, "Выберите свою цель:", reply_markup=markup)

    elif call.data.startswith("goal_"):
        goal = call.data.replace("goal_", "")
        user_settings[user_id] = user_settings.get(user_id, {})
        user_settings[user_id]["goal"] = goal

        bot.send_message(chat_id, f"Цель установлена: {goal.capitalize()}")
        show_settings_menu(call.message)

    elif call.data == "daily_norm":
        bot.send_message(chat_id, "Введите свою дневную норму ккал:")
        bot.register_next_step_handler_by_chat_id(chat_id, set_daily_norm)

    elif call.data == "calc_norm":
        bot.send_message(chat_id,
            "Введите данные через запятую:\n"
            "Рост (см), Вес (кг), Возраст, Пол (М/Ж), Активность, цель"
        )
        bot.register_next_step_handler_by_chat_id(chat_id, calc_norm_result)

    elif call.data == "back":
        start(call.message)



def get_ingredients(message):
    user_id = message.from_user.id
    items = [x.strip() for x in message.text.split(",")]
    if user_id not in user_data:
        user_data[user_id] = []

    total_kcal = 0
    total_protein = 0
    total_fat = 0
    total_carbs = 0

    for item in items:
        item = item
        params = {
            "app_id": APP_ID,
            "app_key": APP_KEY,
            "ingr": item
        }

        try:
            r = requests.get(url, params=params)
            r.raise_for_status()
            data = r.json()
            parsed = data.get("ingredients", [])[0].get("parsed", [])
            if parsed:
                nutrients = parsed[0].get("nutrients", {})
                kcal = nutrients.get("ENERC_KCAL", {}).get("quantity", 0)
                protein = nutrients.get("PROCNT", {}).get("quantity", 0)
                fat = nutrients.get("FAT", {}).get("quantity", 0)
                carbs = nutrients.get("CHOCDF", {}).get("quantity", 0)
            else:
                kcal = protein = fat = carbs = 0


            total_kcal += kcal
            total_protein += protein
            total_fat += fat
            total_carbs += carbs

            user_data[user_id].append({
                "name": item,
                "calories": kcal,
                "protein": protein,
                "fat": fat,
                "carbs": carbs
            })

            bot.send_message(
                message.chat.id,
                f"Ингредиент: {item}\n"
                f"Калории: {round(kcal)} ккал\n"
                f"Белки: {round(protein, 1)} г\n"
                f"Жиры: {round(fat, 1)} г\n"
                f"Углеводы: {round(carbs, 1)} г"
            )

        except Exception as e:
            print(f"Ошибка с {item}: {e}")
            bot.send_message(message.chat.id, f"Упс, ошибка с {item}")

    bot.send_message(
        message.chat.id,
        f"Общий итог по добавленным ингредиентам:\n"
        f"Калории: {round(total_kcal)} ккал\n"
        f"Белки: {round(total_protein, 1)} г\n"
        f"Жиры: {round(total_fat, 1)} г\n"
        f"Углеводы: {round(total_carbs, 1)} г"
    )



def show_settings(chat_id, user_id):
    items = user_data.get(user_id, [])
    if not items:
        bot.send_message(chat_id,  "Список продуктов пуст." )
        return
    kcal = protein = fat = carbs = 0
    for item in items:
        kcal += item.get("calories", 0)
        protein += item.get("protein", 0)
        fat += item.get("fat", 0)
        carbs += item.get("carbs", 0)

    bot.send_message(
        chat_id,
        f"📊 Твой итог:\n"
        f"Калории: {round(kcal)} ккал\n"
        f"Белки: {round(protein)} г\n"
        f"Жиры: {round(fat)} г\n"
        f"Углеводы: {round(carbs)} г"
    )


def show_result(chat_id):
    user_id = chat_id
    items = user_data.get(user_id, [])
    if not items:
        bot.send_message(chat_id, "Список пуст.")
        return

    total_kcal = total_protein = total_fat = total_carbs = 0
    text = "Итоги по добавленным ингредиентам:\n"

    for item in items:
        kcal = item.get('calories', 0)
        protein = item.get('protein', 0)
        fat = item.get('fat', 0)
        carbs = item.get('carbs', 0)

        text += f"{item.get('name', 'Продукт')}: {round(kcal)} ккал, " \
                f"{round(protein, 1)}г белков, " \
                f"{round(fat, 1)}г жиров, " \
                f"{round(carbs, 1)}г углеводов\n"

        total_kcal += kcal
        total_protein += protein
        total_fat += fat
        total_carbs += carbs

    text += f"\nОбщий итог:\n" \
            f"Калории: {round(total_kcal)} ккал\n" \
            f"Белки: {round(total_protein, 1)} г\n" \
            f"Жиры: {round(total_fat, 1)} г\n" \
            f"Углеводы: {round(total_carbs, 1)} г"

    bot.send_message(chat_id, text)


def set_daily_norm(message):
   try:
       calories = int(message.text)
       user_id = message.from_user.id
       user_settings[user_id] = user_settings.get(user_id, {})
       user_settings[user_id] ["calories"] = calories
       bot.send_message(message.chat.id, f"Норма установлена: {calories} ккал")

       show_settings(message.chat.id, message.from_user.id)
   except Exception as e:
       print(e)
       bot.send_message(message.chat.id,"Ошибка.Введите число.")
def calc_norm_result(message):
    try:
        height, weight, age, gender, activity, goal = message.text.split(",")
        height = float(height)
        weight = float(weight)
        age = int(age)
        gender = gender.lower()
        activity = activity.lower()
        goal = goal.lower()
        user_id = message.from_user.id
        goal = user_settings.get(user_id, {}).get(goal, "Поддержание веса")
        calories = calculator(weight, height, age, gender, activity.lower(), goal)
        user_settings[user_id] = user_settings.get(user_id, {})
        user_settings[user_id] ["calories"] = calories
        bot.send_message(message.chat.id,f"Ваша дневная норма калорий: {calories} ккал")
        show_settings(message.chat.id, message.from_user.id)
    except Exception as e:
        print(e)
        bot.send_message(message.chat.id, "Ошибка.Введите все данные через запятую:\n"
                                          "Рост, Вес, Возраст, Пол (М/Ж), Активность, Цель")


def show_settings_menu(message):
    chat_id = message.chat.id
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("Цель", callback_data="goal"),
        types.InlineKeyboardButton("Ежедневная норма ккал", callback_data="daily_norm"),
        types.InlineKeyboardButton("Рассчитать норму ккал", callback_data="calc_norm"),
        types.InlineKeyboardButton("Назад", callback_data="back")
    )
    bot.send_message(chat_id, "Настройки:", reply_markup=markup)




print("a")
bot.polling(none_stop=True)











